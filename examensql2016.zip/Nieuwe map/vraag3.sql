SELECT gemeente "Gemeente", achternaam "Achternaam", voornaam "Voornaam"
FROM KLANT
WHERE gemeente = (SELECT gemeente FROM KLANT WHERE lower(achternaam) = lower('&achternaan') AND lower(voornaam) = lower('&voornaam'))
/
