CREATE VIEW aantalboek(voornaam, familienaam, aantalboeken)
AS SELECT a.voornaam, a.achternaam, COUNT(ba.ISBN)
FROM auteur a
JOIN boek_auteur ba
ON a.auteurnr = ba.auteur_id
GROUP BY a.voornaam
HAVING COUNT(ba.ISBN) > 1
/
