UPDATE boek
SET prijs= prijs+1
WHERE ISBN = ANY (SELECT ba.ISBN FROM boek_auteur ba JOIN auteur a ON ba.auteur_id = a.auteurnr WHERE a.voornaam ='Mieke' AND a.achternaam = 'Vanpol')
/
