SELECT k.achternaam, c.datum, b.titel, a.achternaam
FROM klant k
JOIN caddy c
ON c.klant_id = k.klantnr
JOIN caddy_boek cb
ON c.caddy_id = cb.caddy_id
JOIN boek b
ON b.ISBN = cb.ISBN
JOIN boek_auteur ba
ON ba.ISBN = b.ISBN
JOIN auteur a
ON ba.auteur_id = a.auteurnr
ORDER BY k.achternaam
/
