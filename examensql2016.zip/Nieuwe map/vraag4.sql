SELECT k.achternaam, k.voornaam, k.paswoord, k.gemeente, g.postcode
FROM klant k
JOIN gemeente g
ON k.gemeente = g.gemeente
WHERE g.postcode BETWEEN 3000 AND 4000
AND
 k.paswoord LIKE ('%*%')
OR k.paswoord LIKE ('%/%')

/
