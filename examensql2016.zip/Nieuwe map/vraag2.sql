CREATE TABLE winkel
(winkel_id  NUMBER(4)
CONSTRAINT win_winkel_id_pk PRIMARY KEY
,winkelnaam VARCHAR2(15)
CONSTRAINT win_winkelnaam_ck CHECK (winkelnaam LIKE ('W%'))
,straat VARCHAR2(20)
,huisnr VARCHAR2(10)
,gemeente VARCHAR(25)
CONSTRAINT win_gemeente_fk REFERENCES
gemeente(gemeente)
,klantnr NUMBER(6)
CONSTRAINT win_klantnr_fk REFERENCES
klant(klantnr))
/
